public class StiefelUmap implements StiefelSchuhe {
    String info = "Umap" ;

    public StiefelUmap(){
        System.out.println(this.info + " " + this.type);

    }
}
