public class main {


    EnkiSchuhfabrik.createSchuhe();
    DidadasSchuhfabrik.createSchuhe();
    UmapSchuhfabrik.createSchuhe();

}
