public class SportschuheDidadas implements SportSchuhe {
    String info = "Didadas" ;

    public SportschuheDidadas(){
        System.out.println(this.info + " " + this.type);

    }
}