public class StiefelEnki implements StiefelSchuhe {
    String info = "Enki" ;

    public StiefelEnki(){
        System.out.println(this.info + " " + this.type);

    }
}
