public interface WanderSchuhe extends Schuhe {
    String type = "Wanderschuhe";
}
