public class WanderSchuheUmap implements WanderSchuhe {
    String info = "Umap" ;

    public WanderSchuheUmap() {
        System.out.println(this.info + " " + this.type);

    }

}

