public class SportschuheUmap implements SportSchuhe {
    String info = "Umap" ;

    public SportschuheUmap(){
        System.out.println(this.info + " " + this.type);

    }
}