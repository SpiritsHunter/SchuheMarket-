public interface SportSchuhe extends Schuhe {
    String type = "Sportschuhe";
}
