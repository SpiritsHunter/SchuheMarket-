public class SportschuheEnki implements SportSchuhe {
    String info = "Enki" ;

    public SportschuheEnki(){
        System.out.println(this.info + " " + this.type);

    }
}