public class StiefelDidadas implements StiefelSchuhe {
    String info = "Didadas" ;

    public StiefelDidadas(){
        System.out.println(this.info + " " + this.type);

    }
}
