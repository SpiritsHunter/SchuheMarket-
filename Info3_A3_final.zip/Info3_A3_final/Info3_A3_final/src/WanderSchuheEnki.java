public class WanderSchuheEnki implements WanderSchuhe {
    String info = "Enki" ;

    public WanderSchuheEnki(){
        System.out.println(this.info + " " + this.type);

    }


}
