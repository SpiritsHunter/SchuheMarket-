public class WanderSchuheDidadas implements WanderSchuhe {
    String info = "Didadas" ;

    public WanderSchuheDidadas(){
        System.out.println(this.info + " " + this.type);

    }
}
