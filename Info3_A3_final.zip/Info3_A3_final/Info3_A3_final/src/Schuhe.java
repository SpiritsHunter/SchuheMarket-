public interface Schuhe {
    String type;
    String  info;
}
