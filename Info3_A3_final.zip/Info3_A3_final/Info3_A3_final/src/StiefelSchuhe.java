public interface StiefelSchuhe extends Schuhe {
    String type = "Stiefel";
}
