public interface Schuhfabrik {
    public void createSchuhe();
}
